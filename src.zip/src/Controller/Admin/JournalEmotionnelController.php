<?php

namespace App\Controller\Admin;

use App\Entity\JournalEmotionnel;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Form\JournalEmotionnelType;
use App\Enum\EmotionEnum;
use App\Entity\Utilisateur;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Mailer\MailerInterface;      // ← AJOUTER
use Symfony\Component\Mime\Email;
use Symfony\Component\Mime\Address;
use Psr\Log\LoggerInterface;

#[Route('/admin/journals')]
class JournalEmotionnelController extends AbstractController
{
      public function __construct(
        private MailerInterface $mailer,
        private LoggerInterface $logger  // ← AJOUTER
    ) {}
#[Route('/', name: 'admin_dash')] // Ou la route que vous voulez
public function index(Request $request, EntityManagerInterface $em): Response
{
    $search = $request->get('search');
    
    // Récupérer les utilisateurs
    $qb = $em->getRepository(Utilisateur::class)->createQueryBuilder('u');
    if ($search) {
        $qb->where('u.email LIKE :search OR u.nom LIKE :search OR u.prenom LIKE :search')
           ->setParameter('search', '%' . $search . '%');
    }
    $users = $qb->getQuery()->getResult();
    
    // Récupérer les journaux (si besoin)
   $journals = $em->getRepository(JournalEmotionnel::class)->findBy([], ['dateCreation' => 'DESC'], 50);    
    return $this->render('admin/journal/index.html.twig', [
        'users' => $users,
        'journals' => $journals,
        'emotions' => EmotionEnum::cases(),
        'filters' => []
    ]);
}
// Dans App\Controller\Admin\JournalEmotionnelController.php

#[Route('/admin/journal/{id}/delete', name: 'admin_journal_delete', methods: ['POST'])]
    public function delete(
        JournalEmotionnel $journal,
        EntityManagerInterface $em
    ): Response {
        $utilisateur = $journal->getUtilisateur();
        $userId = $utilisateur->getId();

        // ✅ Envoyer l'email AVANT la suppression
        $this->sendEmail(
            $utilisateur->getEmail(),
            $utilisateur->getPrenom() . ' ' . $utilisateur->getNom(),
            'journal_deleted',
            [
                'userName' => $utilisateur->getPrenom(),
                'date'     => $journal->getDateCreation()->format('d/m/Y à H:i'),
                'emotion'  => $journal->getEmotion()->label(),
            ]
        );

        $em->remove($journal);
        $em->flush();

        $this->addFlash('success', 'Journal supprimé et email envoyé au client.');
        return $this->redirectToRoute('admin_user_journals', ['id' => $userId]);
    }

#[Route('/{id}/edit', name: 'admin_journal_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, JournalEmotionnel $journal, EntityManagerInterface $em): Response
    {
        $form = $this->createForm(JournalEmotionnelType::class, $journal, [
            'journal' => $journal,
        ]);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $emotionValue = $request->request->get('emotion');
            if ($emotionValue) {
                $emotion = EmotionEnum::tryFrom($emotionValue);
                if ($emotion) {
                    $journal->setEmotion($emotion);
                }
            }

            if ($form->has('removeImage') && $form->get('removeImage')->getData()) {
                if ($journal->getImage()) {
                    @unlink($this->getParameter('journal_images_dir') . '/' . $journal->getImage());
                    $journal->setImage(null);
                }
            }

            if ($imageFile = $form->get('imageFile')->getData()) {
                $imageName = uniqid() . '.' . $imageFile->guessExtension();
                $imageFile->move($this->getParameter('journal_images_dir'), $imageName);
                $journal->setImage($imageName);
            }

            if ($form->has('removeAudio') && $form->get('removeAudio')->getData()) {
                if ($journal->getAudio()) {
                    @unlink($this->getParameter('journal_audio_dir') . '/' . $journal->getAudio());
                    $journal->setAudio(null);
                }
            }

            if ($audioFile = $form->get('audioFile')->getData()) {
                $audioName = uniqid() . '.' . $audioFile->guessExtension();
                $audioFile->move($this->getParameter('journal_audio_dir'), $audioName);
                $journal->setAudio($audioName);
            }

            $em->flush();

            // ✅ Envoyer l'email après la sauvegarde
            $utilisateur = $journal->getUtilisateur();
            $this->sendEmail(
                $utilisateur->getEmail(),
                $utilisateur->getPrenom() . ' ' . $utilisateur->getNom(),
                'journal_modified',
                [
                    'userName' => $utilisateur->getPrenom(),
                    'date'     => $journal->getDateCreation()->format('d/m/Y à H:i'),
                    'emotion'  => $journal->getEmotion()->label(),
                    'contenu'  => $journal->getContenu(),
                ]
            );

            $this->addFlash('success', 'Journal modifié et email envoyé au client.');
            return $this->redirectToRoute('admin_user_journals', [
                'id' => $journal->getUtilisateur()->getId()
            ]);
        }

        return $this->render('admin/journal/_edit_modal.html.twig', [
            'form'     => $form->createView(),
            'journal'  => $journal,
            'emotions' => EmotionEnum::cases(),
        ]);
    }
#[Route('/admin/users', name: 'admin_users_index')]
public function usersIndex(Request $request, EntityManagerInterface $em): Response
{
    $search = $request->get('search', '');

    $qb = $em->getRepository(Utilisateur::class)->createQueryBuilder('u')
        ->where('u.role LIKE :role')
        ->setParameter('role', '%ROLE_CLIENT%');

    if ($search) {
        $qb->andWhere('u.email LIKE :search OR u.nom LIKE :search OR u.prenom LIKE :search')
           ->setParameter('search', '%' . $search . '%');
    }

    // Si c'est une requête Ajax, retourner du JSON
    if ($request->isXmlHttpRequest()) {
        $users = $qb->getQuery()->getResult();
        return $this->json(array_map(fn($u) => [
            'id'          => $u->getId(),
            'prenom'      => $u->getPrenom(),
            'nom'         => $u->getNom(),
            'email'       => $u->getEmail(),
            'nbJournaux'  => $u->getJournaux()->count(),
            'journalsUrl' => $this->generateUrl('admin_user_journals', ['id' => $u->getId()]),
            'exportUrl'   => $this->generateUrl('app_admin_journal_export_pdf', ['userId' => $u->getId()]),
        ], $users));
    }

    // Sinon rendu HTML normal
    return $this->render('admin/journal/users.html.twig', [
        'users' => $qb->getQuery()->getResult()
    ]);
}

 #[Route('/admin/api/user/{id}/journals', name: 'admin_api_user_journals', methods: ['GET'])]
    public function getUserJournals(Utilisateur $user): JsonResponse
    {
        $journals = [];
        foreach ($user->getJournaux() as $journal) {
            $journals[] = [
                'id' => $journal->getId(),
                'date' => $journal->getDateCreation()->format('d/m/Y'),
                'time' => $journal->getDateCreation()->format('H:i'),
                'emotion' => $journal->getEmotion()->value,
                'emotionLabel' => $journal->getEmotion()->label(),
                'emotionIcon' => $journal->getEmotion()->icon(),
                'emotionClass' => $this->getEmotionClass($journal->getEmotion()),
                'contenu' => $journal->getContenu(),
                'image' => $journal->getImage() ? true : false,
                'imageUrl' => $journal->getImage() ? '/uploads/journals/images/' . $journal->getImage() : null,
                'audio' => $journal->getAudio() ? true : false,
                'audioUrl' => $journal->getAudio() ? '/uploads/journals/audio/' . $journal->getAudio() : null,
            ];
        }
        
        return $this->json($journals);
    }
private function getEmotionClass(EmotionEnum $emotion): string
{
    return match($emotion) {
        EmotionEnum::TRES_BIEN => 'emotion-tres-bien',
        EmotionEnum::BIEN => 'emotion-bien',
        EmotionEnum::NEUTRE => 'emotion-neutre',
        EmotionEnum::PAS_BIEN => 'emotion-pas-bien',
        EmotionEnum::TRES_MAL => 'emotion-tres-mal',
    };
}
   #[Route('/admin/user/{id}/journals', name: 'admin_user_journals')]  // Pour journal/index.html.twig
public function userJournals(Utilisateur $user): Response
{
    return $this->render('admin/journal/index.html.twig', [  // ✅ Utilise journal/index.html.twig
        'user' => $user
    ]);
}
 // ✅ Méthode helper pour envoyer les emails
    private function sendEmail(string $toEmail, string $toName, string $template, array $context): void
    {
        try {
            $this->logger->info("📧 Tentative envoi email à : {$toEmail}, template: {$template}");

            $email = (new Email())
                ->from(new Address('noreply@feelsafe.com', 'FeelSafe'))
                ->to($toEmail)
                ->subject($template === 'journal_modified'
                    ? '📝 Votre journal a été modifié'
                    : '🗑️ Votre journal a été supprimé'
                )
                ->html($this->renderView("admin/journal/{$template}.html.twig", $context));

            $this->mailer->send($email);
            $this->logger->info("✅ Email envoyé avec succès à : {$toEmail}");

        } catch (\Exception $e) {
            // Avant il était silencieux — maintenant on log l'erreur
            $this->logger->error("❌ Erreur envoi email : " . $e->getMessage());
            // Afficher aussi dans les flash messages pour le debug
            $this->addFlash('error', 'Erreur email : ' . $e->getMessage());
        }
    }
}
